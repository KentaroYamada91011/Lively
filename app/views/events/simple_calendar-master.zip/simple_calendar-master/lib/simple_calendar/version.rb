module SimpleCalendar
  VERSION = "2.3.0"
end
