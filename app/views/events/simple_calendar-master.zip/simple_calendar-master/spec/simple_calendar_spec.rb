require 'spec_helper'
require 'rails'
require 'simple_calendar'

describe SimpleCalendar do
  it 'has a version number' do
    expect(SimpleCalendar::VERSION).not_to be nil
  end
end
