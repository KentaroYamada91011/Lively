require "spec_helper"
require "generators/simple_calendar/views_generator"

describe SimpleCalendar::Generators::ViewsGenerator do
    it 'copies the files to app/views/simple_calendar'
    it 'verifies the content'
end